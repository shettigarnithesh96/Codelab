// string length : strlen(str1);
// string copy : strcpy(destination, source);
//string compare : strcmp(str1, str2);
//string concate : strcat(str1, str2);
//string lower : strlur(str;)
//string upper : strupr(str);


#include <stdio.h>
#include <string.h>
void main(){
    int len;
    char str[10];
    printf("Enter the string: ");
    gets(str);
    len=strlen(str);
    printf("Length");
}