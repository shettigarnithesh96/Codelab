#include <stdio.h>
#include <string.h>

int main(){
    char str[] = "Hello";
    printf("Length: %d\n", strlen(str));
    return 0;
}