//A structure can contain other structures as members
#include <stdio.h>
#include <string.h>

struct Address{
    char city[50];
    char state[50];
};

struct Person{
    char name[50];
    int age;
    struct Address address;
};
