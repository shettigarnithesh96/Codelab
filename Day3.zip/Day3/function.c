//Block of code used to perform something
/*return type F_name(argument)
    {
    Body
    return;
    }
    */

// #include<stdio.h>
// // Function declaration
// int add(int a, int b);

// int main(){
//     //Function call
//     int sum = add(5,3);
//     printf("Sum: %d",sum);
//     return 0;
// }
// //Function definition
// int add(int a,int b){
//     return a+b;
// }

#include<stdio.h>
int sum(int a,int b);
int main(){
    int ans = sum(10,20);
    printf("Sum is: %d",ans);
    return 0;
}
int sum(int a,int b){
    return a+b;
}

