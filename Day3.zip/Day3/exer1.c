#include<stdio.h>
int cal(int a, int b);
int main(){
    int ans = cal(5,10);
    return 0;
}
int cal(int a, int b){
    printf("Sum : %d\n",a+b);
    printf("Sub : %d\n",a-b);
    printf("Mul : %d\n",a*b);
    printf("Div : %d\n",a/b);
}
