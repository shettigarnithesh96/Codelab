#include <stdio.h>
#define SIZE 5
int top =-1;
int stack[SIZE];
void push(int a){
    if(SIZE-1 == top){
        printf("Stack Over Flow\n");
        return ;
    }
    stack[++top] = a;
}

int pop(){
    if(top == -1){
        printf("Stack Under Flow\n");
        return -1;
    }
    return stack[top--];
}
int peek(){
    if(top == -1){
        printf("Stack Under Flow\n");
        return -1;
    }
    return stack[top];
}
void main(){
    push(22);
    printf("%d\n",pop());
    push(56);
    printf("%d\n",pop());
    printf("%d\n",peek());
    printf("%d\n",pop());
    push(5);
    printf("%d\n",peek());
}
