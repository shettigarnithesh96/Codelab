// Homogenos collection of elements of same datatype
//syntax: data_type arr_name[arr_size]
#include<stdio.h>
int main(){
// int arr[5] = {1,2,3,4,5};
// printf("%d",arr[0]); //Access the first element
int arr[5];
printf("Enter the numbers: ");
for(int i = 0;i < 5;i++){
    scanf("%d",&arr[i]);
}
printf("The numbers are: ");
for(int i = 0;i < 5;i++){
    printf("%d",arr[i]);
}
return 0;
}