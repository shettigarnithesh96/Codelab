#include <stdio.h>
#include <string.h>
int main(){
int i;
char str[10];
int len;
for(i=0; str[i]!= '\0';i++){
    len++;
}
}