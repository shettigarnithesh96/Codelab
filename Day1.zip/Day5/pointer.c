// Pointers are variables which points addresses
//Pointer stores the address of the first index
// malloc : make memory
// calloc : make memory and store it as zero
#include <stdio.h>
int main(){
    int a = 5;
    int *ptr1 = &a;
    int **ptr = &ptr1;
    return 0;
}