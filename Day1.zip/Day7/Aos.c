// Array of Structures
#include <stdio.h>
#include <string.h>

struct Person{
    char name[50];
    int age;
    float height;
};
int main(){
    struct Person people[3];

    //Assinging values to members
    strcpy(people[0].name, "Alice");
    people[0].age = 25;
    people[0].height = 5.5;
        //Assinging values to members
    strcpy(people[1].name, "Bob");
    people[1].age = 30;
    people[1].height = 6.0;
        //Assinging values to members
    strcpy(people[2].name, "Charlie");
    people[2].age = 35;
    people[2].height = 5.8;

    for(int i=0;i<3;i++){
        printf("Name: %s, Age: %d, Height: %.1f\n", people[i].name,people[i].age,people[i].height);
    }               
    return 0;
}