#include<stdio.h>
void main(){
printf("Hello World");


int a = 5;
int b = 3;

printf("%d\n", a == b);
printf("%d\n", a != b);
printf("%d\n", a > b);
printf("%d\n", a < b);
printf("%d\n", a >= b);
printf("%d\n", a <= b);

int c = 5;
c++;
printf("c: %d\n", c);

int d = 5;
d--;
printf("d: %d\n", d);

int e = 5;
float f = 2.5;
float result = a+b;
printf("Result: %.2f\n",result);

int h = 5;
int i = 2;
float resultt = (float)a/b;
printf("Result: %.2f\n",resultt);
}