// Dynamic memory allocation
// Dynamic memory allocation is a techinque used to allocate memory at runtime, rather than at compile time
// malloc() : is a function that allocates a block of memory of a specified size
//syntax: datatype pointer variable_name = malloc(10*sizeof(datatype));
// calloc() : is a function that allocates a block of memory of a specified size and initializes all bits to zero
//syntax: datatype pointer variable_name = calloc(10,sizeof(datatype));
// realloc() : is a function that changes the size of a block of memory previously allocated by malloc() or calloc()

#include <stdio.h>
#include <stdlib.h>
int main(){
    int *arr = malloc(10*sizeof(int));
    for(int i=0;i<10;i++){
        arr[i] = i+1;
    }
    for(int i=0;i<10;i++){
        printf("%d",arr[i]);
    }
    return 0;
}
