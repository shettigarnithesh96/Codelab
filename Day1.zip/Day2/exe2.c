#include<stdio.h>
int main(){
    int a=3;
    int b = 5;
    int sum = a+b;
    if(sum % 2 == 0){
        printf("YES");
    }
    else{
        printf("NO");
    }
    return 0;
}