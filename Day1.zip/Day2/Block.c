#include<stdio.h>
void main(){
    int a;
    for(a=1;a<=5;a++){
        printf("%d For loop \n",a);

    }
    int b = 1;
    while (b<=5)
    {
        printf("%d While loop \n",b);
        b++;
    }
    

}