#include <stdio.h>
#include <string.h>
int main(){
    char* data = "Hello, World!";
    fwrite(data, sizeof(char), strlen(data), fp);
    fprintf(fp, "%s", data);
    fclose(fp);
}