#include<stdio.h>

int main() {
    FILE* ptr;
    
    // Opening file in read mode, using double quotes for file name
    ptr = fopen("test.txt", "r");
    
    // Check if file opened successfully
    if (ptr == NULL) {
        printf("Error: Could not open file.\n");
        return 1;
    }
    
    char line[1000];
    
    // Reading from file
    fread(line, sizeof(char), 100, ptr);
    
    // Print the line to the console
    printf("%s", line);
    
    // Closing the file
    fclose(ptr);
    
    return 0;
}