#include<stdio.h>
int main(){
    int arr[4][3],i,j;
    
    printf("Enter array elements: ");

    for(i=0;i<4;i++){
        for(j=0;j<3;j++){
            scanf("%d",&arr[i][j]);
        }
    }
    for(i=0;i<4;i++){
        for(j=0;j<3;j++){
            printf("arr[%d] [%d] = %d \n",i,j,arr[i][j]);
        }
    }

    return 0;       
}