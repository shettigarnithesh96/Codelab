#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int getRandomNumbers(int min, int max){
    return min + rand() % (max - min+1);
}
int main(){
    int numberToGuess,guess,attempts = 0;
    const int maxAttempts = 6;
    srand(time(0));
    numberToGuess = getRandomNumbers(1,100);

    printf("Welcome to the number Guessing Game!\n");
    printf("You have %d attempts to guess the number between 1 and 100.\n",maxAttempts);
    do{
        printf("Enter your guess(1-100): ");
        scanf("%d",&guess);
        attempts++;
        if(guess < numberToGuess){
            printf("Too low!\n");
        }
        else if(guess > numberToGuess){
            printf("Too high!\n");
        }
        else{
            printf("Congragulations! You guessed the number %d in %d attempts.\n",numberToGuess,attempts);
            break;
        }
        if(attempts >= maxAttempts){
            printf("Sorry, you've used al your attempts. The number was %d.\n",numberToGuess);
            break;
        }
    }
    while(1);
    return 0;
}